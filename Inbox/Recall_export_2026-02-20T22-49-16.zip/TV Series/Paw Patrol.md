---
title: Paw Patrol
tags:
  - "TV Series"
createdAt: Sun Nov 30 2025 22:31:38 GMT+0900 (日本標準時)
updatedAt: Sun Nov 30 2025 22:31:38 GMT+0900 (日本標準時)
---


2013 Canadian children's animated television series



## Sources
- [wikipedia_page](https://en.wikipedia.org/wiki/Paw_Patrol)
