---
title: Sesame Street
tags:
  - "TV Series"
createdAt: Fri Nov 21 2025 15:06:32 GMT+0900 (日本標準時)
updatedAt: Fri Nov 21 2025 15:06:32 GMT+0900 (日本標準時)
---


American children's television show



## Sources
- [wikipedia_page](https://en.wikipedia.org/wiki/Sesame_Street)
