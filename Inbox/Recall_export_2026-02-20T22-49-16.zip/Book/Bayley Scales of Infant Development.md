---
title: Bayley Scales of Infant Development
tags:
  - "Book"
createdAt: Tue Nov 18 2025 14:38:49 GMT+0900 (日本標準時)
updatedAt: Tue Nov 18 2025 14:38:49 GMT+0900 (日本標準時)
---


Used to sample the intellectual growth of infants and toddlers



## Sources
- [wikipedia_page](https://en.wikipedia.org/wiki/Bayley_Scales_of_Infant_Development)
