---
title: First Epistle to the Corinthians
tags:
  - "Book"
createdAt: Sun Nov 30 2025 08:21:33 GMT+0900 (日本標準時)
updatedAt: Sun Nov 30 2025 08:21:33 GMT+0900 (日本標準時)
---


Book of the New Testament



## Sources
- [wikipedia_page](https://en.wikipedia.org/wiki/First_Epistle_to_the_Corinthians)
