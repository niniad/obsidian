---
title: Woodcock–Johnson Tests of Cognitive Abilities
tags:
  - "Book"
createdAt: Sun Nov 30 2025 12:07:23 GMT+0900 (日本標準時)
updatedAt: Sun Nov 30 2025 12:07:23 GMT+0900 (日本標準時)
---


Set of intelligence tests



## Sources
- [wikipedia_page](https://en.wikipedia.org/wiki/Woodcock–Johnson_Tests_of_Cognitive_Abilities)
