---
title: Diagnostic and Statistical Manual of Mental Disorders
tags:
  - "Book"
createdAt: Tue Nov 18 2025 14:39:24 GMT+0900 (日本標準時)
updatedAt: Tue Nov 18 2025 14:39:24 GMT+0900 (日本標準時)
---


American psychiatric classification



## Sources
- [wikipedia_page](https://en.wikipedia.org/wiki/Diagnostic_and_Statistical_Manual_of_Mental_Disorders)
