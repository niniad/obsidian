---
title: Stanford–Binet Intelligence Scales
tags:
  - "Book"
createdAt: Tue Nov 18 2025 14:38:49 GMT+0900 (日本標準時)
updatedAt: Tue Nov 18 2025 14:38:49 GMT+0900 (日本標準時)
---


Intelligence test



## Sources
- [wikipedia_page](https://en.wikipedia.org/wiki/Stanford–Binet_Intelligence_Scales)
