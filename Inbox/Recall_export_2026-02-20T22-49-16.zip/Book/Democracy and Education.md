---
title: Democracy and Education
tags:
  - "Book"
createdAt: Sun Nov 30 2025 07:49:06 GMT+0900 (日本標準時)
updatedAt: Sun Nov 30 2025 07:49:06 GMT+0900 (日本標準時)
---


Book by John Dewey



## Sources
- [wikipedia_page](https://en.wikipedia.org/wiki/Democracy_and_Education)
