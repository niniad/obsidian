---
title: Wechsler Intelligence Scale for Children
tags:
  - "Book"
createdAt: Tue Nov 18 2025 14:37:24 GMT+0900 (日本標準時)
updatedAt: Tue Nov 18 2025 14:37:24 GMT+0900 (日本標準時)
---


Popular IQ test for children



## Sources
- [wikipedia_page](https://en.wikipedia.org/wiki/Wechsler_Intelligence_Scale_for_Children)
