---
title: Greg McKeown (author)
tags:
  - "Book"
createdAt: Thu Nov 20 2025 21:06:59 GMT+0900 (日本標準時)
updatedAt: Thu Nov 20 2025 21:06:59 GMT+0900 (日本標準時)
---


Author (born 1977)



## Sources
- [wikipedia_page](https://en.wikipedia.org/wiki/Greg_McKeown_(author))
