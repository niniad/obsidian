---
title: Behavior Rating Inventory of Executive Function
tags:
  - "Book"
createdAt: Tue Nov 18 2025 14:39:24 GMT+0900 (日本標準時)
updatedAt: Tue Nov 18 2025 14:39:24 GMT+0900 (日本標準時)
---


Assessment of executive function behaviors



## Sources
- [wikipedia_page](https://en.wikipedia.org/wiki/Behavior_Rating_Inventory_of_Executive_Function)
