---
title: Bible
tags:
  - "Book"
createdAt: Sun Nov 30 2025 08:21:33 GMT+0900 (日本標準時)
updatedAt: Sun Nov 30 2025 08:21:33 GMT+0900 (日本標準時)
---


Collection of religious texts



## Sources
- [wikipedia_page](https://en.wikipedia.org/wiki/Bible)
