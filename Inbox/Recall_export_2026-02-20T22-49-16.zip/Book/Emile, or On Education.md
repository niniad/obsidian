---
title: Emile, or On Education
tags:
  - "Book"
createdAt: Sun Nov 30 2025 07:49:06 GMT+0900 (日本標準時)
updatedAt: Sun Nov 30 2025 07:49:06 GMT+0900 (日本標準時)
---


1762 book by Jean-Jacques Rousseau



## Sources
- [wikipedia_page](https://en.wikipedia.org/wiki/Emile,_or_On_Education)
