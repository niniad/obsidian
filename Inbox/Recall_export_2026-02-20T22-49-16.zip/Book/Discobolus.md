---
title: Discobolus
tags:
  - "Book"
createdAt: Sun Nov 30 2025 08:03:36 GMT+0900 (日本標準時)
updatedAt: Sun Nov 30 2025 08:03:36 GMT+0900 (日本標準時)
---


Sculpture by Myron



## Sources
- [wikipedia_page](https://en.wikipedia.org/wiki/Discobolus)
