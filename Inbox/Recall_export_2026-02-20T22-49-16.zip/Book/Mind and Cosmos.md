---
title: Mind and Cosmos
tags:
  - "Book"
createdAt: Sun Nov 30 2025 07:59:11 GMT+0900 (日本標準時)
updatedAt: Sun Nov 30 2025 07:59:11 GMT+0900 (日本標準時)
---


2012 book by Thomas Nagel



## Sources
- [wikipedia_page](https://en.wikipedia.org/wiki/Mind_and_Cosmos)
