---
title: Diy懐中電灯の科学技術の小さい製作のスーツは手作りします。
tags:
  - "商品カタログ/おもちゃ"
createdAt: Wed Nov 26 2025 15:44:19 GMT+0900 (日本標準時)
updatedAt: Wed Nov 26 2025 15:44:23 GMT+0900 (日本標準時)
---


Concise summary

- 杭州開宝瑞ネットワーク科技有限公司が販売するDiy懐中電灯の科学技術の小さい製作のスーツは手作りです。
- この商品の価格は15.90元で、1個が最小発注数です。
- 商品の材質は木製で、適用年齢は7-14歳です。




## Sources
- [website](https://detail.1688.com/offer/800967867358.html?spm=a2637j.29680863.landingPageOfferContainer.d_800967867358.6ce4bia9bia9dt&lang=ja&kjSource=pc&fromkv=refer:GVHFGV2ZGNCEMT2KLJMECNCUJJHVEU2VLFKUGN2IIFMUIQKPJJLUONBUIRGU4WSUI5KTIRRWGNCFCSSOKNMFGNJTKBHUUU2GI5NEYQSPJJJFOUKYLJJEONBTIREU2USTI5KTGVCDJZBFISCFGRDDMNRTJ4111111&bizType=selectionTool&customerId=sellerspriteLP)
