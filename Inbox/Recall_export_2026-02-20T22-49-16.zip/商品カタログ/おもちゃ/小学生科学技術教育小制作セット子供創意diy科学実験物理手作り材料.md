---
title: 小学生科学技術教育小制作セット子供創意diy科学実験物理手作り材料
tags:
  - "商品カタログ/おもちゃ"
createdAt: Wed Nov 26 2025 15:42:45 GMT+0900 (日本標準時)
updatedAt: Wed Nov 26 2025 15:43:06 GMT+0900 (日本標準時)
---


Concise summary

- 小学生向けの科学技術教育キット「小学生科学技術教育小制作セット子供創意diy科学実験物理手作り材料」が販売されています。
- このキットは、さまざまな学年向けのセットや科目別のセットなど、多種多様なバリエーションがあります。
- 販売価格は8.60元〜75.00元で、最小発注数は1個です。




## Sources
- [website](https://detail.1688.com/offer/854038624774.html?spm=a2637j.29680863.landingPageOfferContainer.d_854038624774.6ce4bia9bia9dt&lang=ja&kjSource=pc&fromkv=refer:GVHFGV2ZGNCEMT2KLJMECNCUJJHVEU2VLFKUGN2IIEZFISKNIJKEQQJTIRCU4QSYI42DERRWGNCFCSSOKNMFGNJTKBHUUU2GI5NEYQSPJJJFOUKYLJJEONBTIREU2USTI5KTGVCDJZBFISCFGRDDMNRTJ4111111&bizType=selectionTool&customerId=sellerspriteLP)
