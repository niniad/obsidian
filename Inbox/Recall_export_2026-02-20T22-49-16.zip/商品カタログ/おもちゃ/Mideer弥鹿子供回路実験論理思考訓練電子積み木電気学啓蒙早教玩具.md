---
title: Mideer弥鹿子供回路実験論理思考訓練電子積み木電気学啓蒙早教玩具
tags:
  - "商品カタログ/おもちゃ"
createdAt: Wed Nov 26 2025 15:45:23 GMT+0900 (日本標準時)
updatedAt: Wed Nov 26 2025 15:45:47 GMT+0900 (日本標準時)
---


Concise summary

- Mideer弥鹿子供回路実験論理思考訓練電子積み木電気学啓蒙早教玩具は、子供のための電子工作キットです。
- この玩具は、子供が回路を組み立てて実験することで、電子工学の基礎を学ぶことができます。
- 価格は209.03元で、最小発注数は1個です。




## Sources
- [website](https://detail.1688.com/offer/846159013020.html?spm=a2637j.29680863.landingPageOfferContainer.d_846159013020.6ce4bia9bia9dt&lang=ja&kjSource=pc&fromkv=refer:GVHFGV2ZGNCEMT2KLJMECNCUJJHVEU2VLFKUGN2IIEZEITKNJJLEQRKZIRBU2WSRI5EVSRRWGNCFCSSOKNMFGNJTKBHUUU2GI5NEYQSPJJJFOUKYLJJEONBTIREU2USTI5KTGVCDJZBFISCFGRDDMNRTJ4111111&bizType=selectionTool&customerId=sellerspriteLP)
