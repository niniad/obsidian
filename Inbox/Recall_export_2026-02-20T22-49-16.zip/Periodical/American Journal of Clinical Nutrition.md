---
title: American Journal of Clinical Nutrition
tags:
  - "Periodical"
createdAt: Tue Nov 18 2025 11:38:39 GMT+0900 (日本標準時)
updatedAt: Tue Nov 18 2025 11:38:39 GMT+0900 (日本標準時)
---


The American Journal of Clinical Nutrition (AJCN) is a monthly peer-reviewed biomedical journal covering dietetics and clinical nutrition.



## Sources
- [homepage](https://ajcn.nutrition.org/)
