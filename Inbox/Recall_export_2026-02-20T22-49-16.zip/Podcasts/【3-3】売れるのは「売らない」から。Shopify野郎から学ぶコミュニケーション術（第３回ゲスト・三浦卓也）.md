---
title: 【3-3】売れるのは「売らない」から。Shopify野郎から学ぶコミュニケーション術（第３回ゲスト・三浦卓也）
tags:
  - "Podcasts"
createdAt: Fri Nov 14 2025 11:37:25 GMT+0900 (日本標準時)
updatedAt: Fri Nov 14 2025 11:37:28 GMT+0900 (日本標準時)
---


Concise summary

- 三浦卓也はShopifyを利用したビジネスで成功を収めた。
- 「売らない」ことを売りのポイントとしている。
- コミュニケーション術はビジネスで重要である。




## Sources
- [website](https://podcasts.apple.com/jp/podcast/3-3-売れるのは-売らない-から-shopify野郎から学ぶコミュニケーション術-第３回ゲスト-三浦卓也/id1621624946?i=1000568663167)
