---
title: View of Seeking Racial and Ethnic Parity in Preschool Outcomes
tags:
  - "社会/子ども・若者"
createdAt: Sun Nov 30 2025 11:46:43 GMT+0900 (日本標準時)
updatedAt: Sun Nov 30 2025 11:46:45 GMT+0900 (日本標準時)
---


Concise summary











## Sources
- [website](https://journals.ku.edu/jmr/article/view/19540/18363)
