---
title: Spirited Away
tags:
  - "Movie"
createdAt: Thu Nov 20 2025 20:41:43 GMT+0900 (日本標準時)
updatedAt: Thu Nov 20 2025 20:41:43 GMT+0900 (日本標準時)
---


2001 film by Hayao Miyazaki



## Sources
- [wikipedia_page](https://en.wikipedia.org/wiki/Spirited_Away)
