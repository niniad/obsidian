---
title: Screen Time Alternatives For Kids
tags:
  - "スクリーンタイム"
  - "論文・公文書/学習"
createdAt: Fri Nov 21 2025 15:03:36 GMT+0900 (日本標準時)
updatedAt: Fri Nov 21 2025 15:03:39 GMT+0900 (日本標準時)
---


Concise summary





- Edith Bracho-Sanchez




## Sources
- [website](https://www.columbiadoctors.org/news/screen-time-alternatives-kids)
