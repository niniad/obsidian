---
title: The Role of Parental Education, Intelligence, and Personality on the Cognitive Abilities of Gifted Children - PMC
tags:
  - "論文・公文書/学習"
createdAt: Tue Nov 18 2025 22:57:03 GMT+0900 (日本標準時)
updatedAt: Tue Nov 18 2025 22:58:13 GMT+0900 (日本標準時)
---






## Sources
- [website](https://pmc.ncbi.nlm.nih.gov/articles/PMC11856753/)
