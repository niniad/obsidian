---
title: Autism Spectrum Disorder
tags:
  - "Disease"
createdAt: Tue Nov 18 2025 14:39:24 GMT+0900 (日本標準時)
updatedAt: Tue Nov 18 2025 14:39:24 GMT+0900 (日本標準時)
---


Autism spectrum disorder (ASD) is a neurodevelopmental condition characterized by difficulties in social communication and interaction, restricted and repetitive behaviors, sensory sensitivities, and a preference for routine.



## Sources
- [homepage](https://www.autismspeaks.org)
