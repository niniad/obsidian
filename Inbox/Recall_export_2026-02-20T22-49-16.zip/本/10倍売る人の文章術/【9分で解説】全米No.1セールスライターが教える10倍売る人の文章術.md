---
title: 【9分で解説】全米No.1セールスライターが教える10倍売る人の文章術
tags:
  - "ソース/Youtube"
  - "本/10倍売る人の文章術"
createdAt: Thu Nov 20 2025 21:27:43 GMT+0900 (日本標準時)
updatedAt: Thu Nov 20 2025 21:28:02 GMT+0900 (日本標準時)
---


Concise summary

- 全米No.1セールスライターが教える10倍売る人の文章術という書籍では、売れる文章術を解説しており、ブログやメール、マガジン、SNSに投稿して大量に反応が返ってくるようになる方法が紹介されている [(00:00:13)](https://www.youtube.com/watch?v=TTM-FV54eeQ&t=13s)
- 人を動かす文章を書くためには、お客様は読まない、信じない、行動しないという3つの心理的ブロックを突破する必要があり、セールスライティングでは滑り台効果が重要である [(00:01:27)](https://www.youtube.com/watch?v=TTM-FV54eeQ&t=87s)
- コピーライティングの中心となる3つの真理ブロックのうち、読まない心理ブロックを突破する方法について、滑り台効果、読者が関心を持つコピーを書くこと、商品やサービスではなくコンセプトを売ることが重要である [(00:02:31)](https://www.youtube.com/watch?v=TTM-FV54eeQ&t=151s)




## Sources
- [website](https://www.youtube.com/watch?v=TTM-FV54eeQ)
