---
title: #94【石原明】成長曲線を描こう。夢をかなえる仕事のヒント【毎日おすすめ本読書レビュー・紹介・Reading Books】
tags:
  - "ソース/Youtube"
  - "本/成功曲線を描こう"
createdAt: Thu Nov 20 2025 20:33:13 GMT+0900 (日本標準時)
updatedAt: Thu Nov 20 2025 20:33:17 GMT+0900 (日本標準時)
---


Concise summary

- 成長曲線を描こうというタイトルの本を紹介しており、成長していく曲線をより高い伸び率で自分の能力を向上させていくための考え方や方法が書いてあります [(00:00:11)](https://www.youtube.com/watch?v=IebNmwA_Ixc&t=11s)
- 本の中では、左脳型と右脳型の違いについて書いてあり、右脳型の方が成功しやすいとされています。また、右脳型の人は楽しさをキープしながらやっていくことができるとも書いてあります [(00:01:27)](https://www.youtube.com/watch?v=IebNmwA_Ixc&t=87s)
- 目標の立て方についても書いてあり、トップダウンの目標設定とボトムアップの目標設定のバランスを上手く取ることが重要だとされています [(00:03:46)](https://www.youtube.com/watch?v=IebNmwA_Ixc&t=226s)




## Sources
- [website](https://www.youtube.com/watch?v=IebNmwA_Ixc)
