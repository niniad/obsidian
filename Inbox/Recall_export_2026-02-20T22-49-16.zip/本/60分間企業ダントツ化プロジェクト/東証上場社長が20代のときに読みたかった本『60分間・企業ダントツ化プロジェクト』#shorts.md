---
title: 東証上場社長が20代のときに読みたかった本『60分間・企業ダントツ化プロジェクト』#shorts
tags:
  - "ソース/Youtube"
  - "本/60分間企業ダントツ化プロジェクト"
createdAt: Thu Nov 20 2025 21:13:45 GMT+0900 (日本標準時)
updatedAt: Thu Nov 20 2025 21:13:48 GMT+0900 (日本標準時)
---


Concise summary

- いいものを作るだけでは売れない、いいものを作るプラス何が必要だったのかを学ぶことが重要である [(00:00:00)](https://www.youtube.com/watch?v=COrBCSDbg2Q&t=0s)
- 商品はリーズがあるだけでは売れない、適切なターゲットに効果的にアプローチできなければ売上にはつながらない [(00:00:25)](https://www.youtube.com/watch?v=COrBCSDbg2Q&t=25s)
- ターゲットが広いことが悲しも有利ではない、特定のニーズを持つ絞り込まれた層を狙う方が効果的な場合もある [(00:00:36)](https://www.youtube.com/watch?v=COrBCSDbg2Q&t=36s)




## Sources
- [website](https://www.youtube.com/watch?v=COrBCSDbg2Q)
