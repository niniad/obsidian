---
title: 【本要約】金儲けのレシピ（著者；事業家bot 氏）
tags:
  - "ソース/Youtube"
  - "本/金儲けのレシピ"
createdAt: Thu Nov 20 2025 21:12:34 GMT+0900 (日本標準時)
updatedAt: Thu Nov 20 2025 21:13:01 GMT+0900 (日本標準時)
---


Concise summary

- 金儲けのレシピの本書の結論は、普通の商売は儲からない、ニッお客様に働いてもらうを考え、権威になれ、根源のニーズを満たせの4つです [(00:00:28)](https://www.youtube.com/watch?v=aqO8wxHwzik&t=28s)
- 普通の商売は儲からないのは、完全競争市場において低価格販売を行うと最終的に利益は自分の働いた分しか登らないからです [(00:01:56)](https://www.youtube.com/watch?v=aqO8wxHwzik&t=116s)
- お客様に働いてもらうことを考え、特殊な構造を作ることで儲けることができるのです、お客様にサービスしてもらう例としては焼肉屋やイケアがあります [(00:03:41)](https://www.youtube.com/watch?v=aqO8wxHwzik&t=221s)
- 権威になれということは、勝手に敬意になることで儲かることができるのです、例えば資格を作る側になることや格付けをすることです [(00:05:42)](https://www.youtube.com/watch?v=aqO8wxHwzik&t=342s)




## Sources
- [website](https://www.youtube.com/watch?v=aqO8wxHwzik)
