---
title: 事業家bot 著「金儲けのレシピ｣　実業之日本社　　【ナイスクサテライト】
tags:
  - "ソース/Youtube"
  - "本/金儲けのレシピ"
createdAt: Thu Nov 20 2025 21:12:41 GMT+0900 (日本標準時)
updatedAt: Thu Nov 20 2025 21:13:11 GMT+0900 (日本標準時)
---


Concise summary

- 株式会社実業之日本社は、中小の出版社ですが、小説、マンガ、ビジネス書など、オールジャンルで出版を行っています [(00:00:25)](https://www.youtube.com/watch?v=2QETdxaN8t0&t=25s)
- 白土様は、ビジネス書や自己啓発書を担当しており、最近は「金儲けのレシピ」という本を出版しました [(00:00:55)](https://www.youtube.com/watch?v=2QETdxaN8t0&t=55s)
- この本では、15のレシピを紹介し、世の中のビジネスや会社がどういう仕組みでお金を儲けているのかを説明しています [(00:03:33)](https://www.youtube.com/watch?v=2QETdxaN8t0&t=213s)




## Sources
- [website](https://www.youtube.com/watch?v=2QETdxaN8t0)
