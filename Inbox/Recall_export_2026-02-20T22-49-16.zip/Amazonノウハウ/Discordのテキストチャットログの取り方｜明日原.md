---
title: Discordのテキストチャットログの取り方｜明日原
tags:
  - "Amazonノウハウ"
createdAt: Thu Nov 13 2025 15:37:23 GMT+0900 (日本標準時)
updatedAt: Thu Nov 13 2025 15:37:36 GMT+0900 (日本標準時)
---


Concise summary

- Discordのテキストチャットログを取得するために、「[[DiscordChatExporter]]」というソフトを使用します。
- ログを取得するには、Discordのトークン（authorization）を取得し、「DiscordChatExporter.exe」にトークンを入力する必要があります。
- トークンを入力した後、サーバーとチャンネルを選択し、ログの出力形式（TXT、HTML、CSVなど）を選択して「EXPORT」をクリックすると、ログファイルが出力されます。




## Sources
- [website](https://note.com/as_hr/n/n1dfec743eedf)
