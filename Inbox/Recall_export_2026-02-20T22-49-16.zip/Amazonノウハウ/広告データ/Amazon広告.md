---
title: Amazon広告
tags:
  - "Amazonノウハウ/広告データ"
createdAt: Sat Dec 06 2025 23:37:00 GMT+0900 (日本標準時)
updatedAt: Sat Dec 06 2025 23:37:08 GMT+0900 (日本標準時)
---


Concise summary

- Amazon広告では、キャンペーンを作成したり、キャンペーンマネージャーを使用したりすることができます。
- ブランドプロフィールやブランドストアの作成、クリエイティブアセットの管理が可能です。
- レポートや広告プランナー、Amazonアトリビューションなどのツールも利用できます。




## Sources
- [website](https://advertising.amazon.co.jp/marketing-cloud/use-cases/?quickFilters=Sponsored+Ads&quickFilters=Analytics&entityId=ENTITY3OZUEJGP4YU9P)
