---
title: tas 月別収支データテンプレート
tags:
  - "Amazonノウハウ"
createdAt: Thu Nov 13 2025 15:02:21 GMT+0900 (日本標準時)
updatedAt: Thu Nov 13 2025 15:02:39 GMT+0900 (日本標準時)
---


Concise summary

- Amazonの月間売上は5万万円、注文個数は1万3千。
- 直販サイト([[Shopify]])の月間売上は1万8千万円、注文個数は5千。
- Amazonと直販サイト(Shopify)の営業利益率はそれぞれ21.70%と31.31%。




## Sources
- [website](https://docs.google.com/spreadsheets/d/1FjIo0Zwe6n3DgSI5MWCxUXVuamS_AtYtqHNrDl8q9ts/edit?gid=105347259#gid=105347259)
